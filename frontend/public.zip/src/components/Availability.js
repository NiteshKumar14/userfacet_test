import React from 'react'
import { useEffect, useState } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import Table from 'react-bootstrap/Table';
import Card from 'react-bootstrap/Card';
import axios from 'axios';
import { v4 as uuidv4 } from 'uuid';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

export default function Availability() {
    const [data, setData] = useState("");
    const [isOpen,setIsOpen] = useState(false);
    const [weekDay,setWeekDay] = useState("");
    const [startTime,setStartTime] = useState("");
    const [endTime,setEndTime] = useState("");
    const notify = (message) => toast(message);
    useEffect(() => {
        const url = "http://localhost:3000/api/getTeacherDetails";

        const fetchData = async () => {
            try {
                const response = await fetch(url);
                const json = await response.json();
               
                setData(json.data);
                console.log(json);
            } catch (error) {
                console.log("error", error);
            }
        };
        fetchData();
    }, []);


    return (
        <>
            <Card body>Teacher Availability Slots </Card>
            <Card body>Name :{data.full_name} </Card>
            <Card body>Email :{data.email} </Card>

            <Table striped bordered hover variant="dark">
                <thead>
                    <tr>
                        <th>Day</th>
                        <th>Start_time</th>
                        <th>End_time</th>
                    </tr>
                </thead>
                <tbody>
                    
                    {
                        (()=>{
                            if(data.availability)
                           {
                          
                            for (const [key, value] of Object.entries(data.availability)) {
                                return (
                                    <>
                                    {value.map((val)=>{
                                        return (
                                            <tr key={uuidv4()}>
                                            <td >{key}</td>
                                            <><td key={uuidv4()}>{val.start_time}</td>
                                            <td key={uuidv4()}>{val.end_time}</td></>
                                            </tr>
                                            
                                        )
                                    })}
                                    </>
                                    
                               )
                              }
                           }

                        })()
                        
                    
                    
                    }
                  
                    
                </tbody>
            </Table>
            <button onClick ={()=>{
                setIsOpen(true);
            }}>Book Slot</button>
            {isOpen && 
            
                <form>
                    <input placeholder="weekday" onChange={(event)=>{
                            setWeekDay(event.target.value);
                    }}></input>
                    <input placeholder="start time" onChange={(event)=>{
                            setStartTime(event.target.value);
                    }}></input>
                    <input placeholder="end time" onChange={(event)=>{
                            setEndTime(event.target.value);
                    }}></input>
                    <button onClick={(e)=>{
                        axios.post("http://localhost:3000/api/scheduleClass",{weekday:weekDay,start_time:startTime,end_time: endTime}).then((data)=>{
                            notify(data.message);
                        })
                    }}>Submit</button>
                </form>
            }

        </>









    )
}

